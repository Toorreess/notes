/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Guillermo Pérez Trabado
 *
 * Created on 19 de abril de 2021, 22:22
 */

#include <stdio.h>
#include <stdlib.h>

#include <mycache.h>

/* Number of registers to use in the test. */
//#define TEST_LENGTH 160000
/* Use less registers while debugging */
#define TEST_LENGTH 4

/*
 * This test uses the library to create some registers and the reads them again.
 */
int
main (int argc, char** argv)
{

  /************************************************************/
  /* WRITE TEST */
  /************************************************************/

  /* This function initializes the cache. */
  if (MYC_initCache () != 0)
    {
      fprintf (stderr, "Error initializing cache.\n");
      exit (1);
    }

  /* This is a variable to hold one record. */
  MYRECORD_RECORD_t record;

  /* Fill register n times and create entries in the DB file. */
  for (int i = 1; i < TEST_LENGTH; i++)
    {
      /* Id of the record. */
      record.registerid = i;
      record.age = i;
      record.gender = -1;
      /* This is a fixed length string. Print into it directly. */
      snprintf (record.name, sizeof (record.name), "reg #%d", i);

      /* Write into cache and probably flush some previous register to file. */
      if (MYC_writeEntry (i, &record) != 0)
        {
          fprintf (stderr, "Error writing to the cache.\n");
          exit (1);
        }
    }

  /* Flush entries of the cache. */
  /* Many of them probably are out of the cache by now. */
  if (MYC_flushAll () != 0)
    {
      fprintf (stderr, "Error flushing cache.\n");
      exit (1);
    }

  /* This function closes the cache. It flushes all the information inside the
   * cache that is not written to the file yet. */
  if (MYC_closeCache () != 0)
    {
      fprintf (stderr, "Error closing cache.\n");
      exit (1);
    }

  fprintf (stderr, "Write test ended OK.\n");

  /************************************************************/
  /* READ TEST */
  /************************************************************/

  /* Open cache again. */
  if (MYC_initCache () != 0)
    {
      fprintf (stderr, "Error initializing cache.\n");
      exit (1);
    }

  /* Read register from DB file. */
  for (int i = 1; i < TEST_LENGTH; i++)
    {
      /* This function reads a record from the cache (at given index)
       * inside the record passed as argument. */
      if (MYC_readEntry (i, &record) != 0)
        {
          fprintf (stderr, "Error reading from cache.\n");
          exit (1);
        }

      /* Check that the index from the record matches the position. */
      if (record.registerid != i)
        {
          fprintf (stderr, "ERROR:: Register at %d contains id %d.\n", i, record.registerid);
        }
    }

  /* This function closes the cache. It flushes all the information inside the
   * cache that is not written to the file yet. */
  if (MYC_closeCache () != 0)
    {
      fprintf (stderr, "Error closing cache.\n");
      exit (1);
    }

  fprintf (stderr, "Read test ended OK.\n");

  return (EXIT_SUCCESS);
}

