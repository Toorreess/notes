/**
 * This file only contains a dummy function to generate a void cache library.
 * The purpose is to avoid build errors from Netbeans as we only want this
 * project as a container for the libraries.
 */
#ifdef __cplusplus
extern "C"
{
#endif
  void dummy_function()
  {
    
  }

#ifdef __cplusplus
}
#endif
