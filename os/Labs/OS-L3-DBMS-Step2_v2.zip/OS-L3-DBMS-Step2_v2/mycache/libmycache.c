/* 
 * File:   libmycache.c
 * Author: Guillermo Pérez Trabado
 *
 * This file implements the library to handle my RAM cache.
 * 
 * The RAM cache is a RAM buffer between a program using records and the DB file.
 * When we want to use a record from the DB file, this library must read it from disk to RAM.
 * 
 * The RAM cache is a table of BUCKETS. Each bucket may contain one register of
 * the DB file. As it is a cache, the record contained on each bucket may change.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "mycache.h"

#define DEBUG_LEVEL 0

/************************************************************
 PRIVATE VARIABLES
 ************************************************************/

/* Use global variables to keep values between functions. */
/* Add the keyword "static" to hide them so that a global variable can't be seen outside
 * this module. */

/* This will be the descriptor for the file returned by open() */
static int dbFile = -1;

typedef struct
{
  /* Space for content of X buckets */
  MYBUCKET_BUCKET_t buckets[MYC_NUMENTRIES];
  /* State of each buffer. -1: busy, 0: free */
  int used[MYC_NUMENTRIES];
  /* Synchronization state of each buffer. -1: needs write, 0: clean */
  int dirty[MYC_NUMENTRIES];
} MYC_CACHE_t;


/* You also need a array of buckets to use them as a RAM cache. */
static MYC_CACHE_t *CacheEntries = NULL;

/************************************************************
 PRIVATE FUNCTIONS
 ************************************************************/

/* Use the keyword "static" before a functions which is only used inside this file */

/**
 * Allocate memory for the cache.
 * @param n Number of buckets of the cache.
 * @return A pointer to a table with the required number of buckets.
 * NULL means a problem allocating memory.
 */
static MYC_CACHE_t *
allocateCache ()
{
  return (MYC_CACHE_t *) calloc (1, sizeof (MYC_CACHE_t));
}

/**
 * Search for an unused entry in the table.
 * If there's no unused one, just one clean entry.
 * If there's no clean one, return -1.
 * @return The index of the selected entry. -1 means that no entry was unused or clean.
 */
static int
searchUnusedOrClean ()
{
  for (int i = 0; i < MYC_NUMENTRIES; i++)
    {
      /* Any entry with id==0 is free. */
      if (0 == CacheEntries->used[i]) return i;
    }

  /* No unused entry in the cache. We have to reuse one clean entry. */
  /* THIS IS A VERY SILLY REPLACEMENT POLICY */
  for (int i = 0; i < MYC_NUMENTRIES; i++)
    {
      /* Any entry with Dirty==0 is free. */
      if (0 == CacheEntries->dirty[i]) return i;
    }

  /* No unused or clean entry */
  return -1;
}

/**
 * Get a random entry from the cache if all entries are dirty.
 * @return A random index.
 */
static int
searchAny ()
{
  int i = rand () % MYC_NUMENTRIES;
#if DEBUG_LEVEL>0
  fprintf (stderr, "DEBUG: searchAny returns %d.\n", i);
#endif            
  return i;
}

/**
 * Search for an entry already associated with an offset of the file.
 * If there's no such entry, return -1.
 * @return The index of the entry already containing recordIndex. -1 means that no entry was found.
 */
static int
searchRecord (int recordIndex)
{
  for (int i = 0; i < MYC_NUMENTRIES; i++)
    {
      /* Check if a used entry contains the bucket at fileIndex. */
      int bucketPosition = recordIndex / MYBUCKET_NRECORDS;
      if (CacheEntries->used[i] && (bucketPosition == CacheEntries->buckets[i].id)) return i;
    }
  /* Not found. */
  return -1;
}

/**
 * This function reads one bucket from the file into the cache.
 * The entry CachesEntries[cacheIndex] of the cache is read from the bucket
 * number fileIndex of the file.
 * @param bucketIndex The index of the bucket in the file.
 * @param cacheIndex The index of the bucket in the cache.
 * @return -1 indicates an error reading the bucket. 0 success.
 */
static int
readBucket (int bucketIndex, int cacheIndex)
{
  /* The memory address of the entry can be obtained with this.*/
  void *src_addr = &(CacheEntries->buckets[cacheIndex]);

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* The file contains a table of MYBUCKET_BUCKET_t. */
  /* Calculate the offset in bytes of the source on this variable. */
  int offset = bucketIndex * sizeof (MYBUCKET_BUCKET_t); /* Replace 0 with calculation */

  int status = lseek (dbFile, offset, SEEK_SET);
  if (status == -1)
    {
      perror ("mycachelib::readBucket. Error positioning in the file.");
      return -1;
    }
  /* Read the bucket containing the record from the file.
   * You use read() to read the memory contents from file. */
  status = read (dbFile, src_addr, sizeof (MYBUCKET_BUCKET_t));
  /* Check status and return -1 in case of error. */
  if (status == -1)
    {
      perror ("mycachelib::readBucket. Error reading bucket from file.");
      return -1;
    }

  /* Remember to update bucket position in file */
  CacheEntries->buckets[cacheIndex].id = bucketIndex;

  /* Remember to set cache entry status */
  CacheEntries->used[cacheIndex] = -1;
  CacheEntries->dirty[cacheIndex] = 0;

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/**
 * This function writes one bucket to the file from the cache.
 * The entry CachesEntries[cacheIndex] of the cache is written to the bucket
 * number fileIndex of the file.
 * @param cacheIndex The index of the bucket in the cache.
 * @param bucketIndex The index of the bucket in the file.
 * @return -1 indicates an error writing the bucket. 0 success.
 */
static int
writeBucket (int cacheIndex, int bucketIndex)
{
  /* The memory address of the entry can be obtained with this.*/
  void *src_addr = &(CacheEntries->buckets[cacheIndex]);

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* The file contains a table of MYBUCKET_BUCKET_t. */
  /* Calculate the offset in bytes of the destination on this variable. */
  int offset = bucketIndex * sizeof (MYBUCKET_BUCKET_t); /* Replace 0 with calculation */

  int status = lseek (dbFile, offset, SEEK_SET);
  if (status == -1)
    {
      perror ("mycachelib::writeBucket. Error positioning in the file.");
      return -1;
    }

  /* Write the bucket containing the record to the file.
   * You use write() to write the memory contents to file. */
  status = write (dbFile, src_addr, sizeof (MYBUCKET_BUCKET_t));
  /* Check status and return -1 in case of error. */
  if (status == -1)
    {
      perror ("mycachelib::writeBucket. Error writing bucket to file.");
      return -1;
    }

  /* Remember to update dirty bucket status */
  CacheEntries->dirty[cacheIndex] = 0;
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/************************************************************
 PUBLIC FUNCTIONS
 ************************************************************/

/* Functions without "static" will be visible from any other C file. */

/* This function initializes the cache. */

/**
 * Initialize the cache: allocate RAM, open file, etc.
 * @return -1 in case of error during initialization. 0 means OK.
 */
int
MYC_initCache ()
{
  /* Allocate memory for the cache. */
  CacheEntries = allocateCache ();
  /* Always check everything, warn and return an error. */
  if (CacheEntries == NULL)
    {
      perror ("Not enough memory for the entry table.");
      return -1;
    }

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* Open the DB file below. */
  /* Insert here the code to open your DB file and leave it open. */
  /* Add the flags to: READ/WRITE the file and CREATE it if it does not
   * exists before.
   * Add the permission flags to set the flags in case of creation.
   */

  dbFile = open (MYC_FILENAME, O_SYNC | O_RDWR | O_CREAT, S_IRWXU);
  if (dbFile == -1)
    {
      perror ("Error opening file\n");
      return -1;
    }

  /* Don't forget to check that the open() has succeded. */
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */

  /* Everything is OK */
  return 0;
}

/**
 * This function finishes the cache. It flushes all the information inside the
 * cache that is not written to the file yet and closes the file.
 * @return 
 */
int
MYC_closeCache ()
{
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* Flush all dirty entries in the cache to the file. */
  MYC_flushAll ();
  /* Close the DB file here. */
  close (dbFile);
  /* Set the file descriptor to -1 to indicate a close file. */
  dbFile = -1;

  /* Free memory of the cache and NULLify pointers. */
  free (CacheEntries);
  CacheEntries = NULL;
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/**
 * This function copies into a record passed as argument from the cache.
 * The cache will be read from the given index of the file if not on the cache.
 * The record structure is property of the user, so we have to copy the content
 * of the cache entry onto it.
 * If the record does not exists, we should return a zero filled record.
 * The caller must be carefull to check that the record has a 0 id.
 * 
 * @param recordIndex This is the index of the record in the file.
 * @param record This is a pointer to a record allocated by the user.
 * @return -1 in case of any error like I/O error when reading. 0 is OK.
 */
int
MYC_readEntry (int recordIndex, MYRECORD_RECORD_t *record)
{
  /* This variable will be the index of the entry of the cache to use. */
  int cacheIndex = 0;

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* REMEMBER TO USE THE AUXILIARY FUNCTIONS ABOVE. */
  /* Search the cache to guess if there's already an entry for "fileIndex". */
  /* If the record was already in the cache copy that entry. */
  cacheIndex = searchRecord (recordIndex);
  if (cacheIndex == -1)
    {
      /* If not, get an unused or clean entry to read from the file. */
      cacheIndex = searchUnusedOrClean ();
      if (cacheIndex == -1)
        {
          /* If not, get a dirty entry, and flush its contents before reading from the file. */
          cacheIndex = searchAny ();
          if (MYC_flushEntry (CacheEntries->buckets[cacheIndex].id * MYBUCKET_NRECORDS) == -1)
            {
              fprintf (stderr, "Error flushing entry to file.\n");
              return -1;
            }
        }
      /* Remember to update the entry with the index of the file that it contains now. */
      /* Set the new entry to the current record. */
      CacheEntries->buckets[cacheIndex].id = recordIndex / MYBUCKET_NRECORDS;
      CacheEntries->dirty[cacheIndex] = 0;
      CacheEntries->used[cacheIndex] = -1;
      /* Read from the file to the cache if needed. */
      if (readBucket (recordIndex / MYBUCKET_NRECORDS, cacheIndex) == -1)
        {
          fprintf (stderr, "Error reading entry from file.\n");
          return -1;
        }
    }

  /* Remember to update the entry with the index of the file that it contains now. */
  CacheEntries->buckets[cacheIndex].id = recordIndex / MYBUCKET_NRECORDS;
  /* Copy from the record inside the cache entry to the record passed as argument. */
  *record = CacheEntries->buckets[cacheIndex].record[recordIndex % MYBUCKET_NRECORDS];
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/*
 * This function copies a record passed as argument into the cache.
 * The record will be written at the given index of the file LATER.
 * This funtions does not write the cache entry to the file inmediately. 
 * The record structure is property of the user, so we have to copy its
 * content to the entry as the record can be deallocated by the user.
 * 
 * @param recordIndex This is the index of the record in the file.
 * @param record This is a pointer to a record allocated by the user.
 * @return -1 in case of any error like I/O error when writing. 0 is OK.
 */
int
MYC_writeEntry (int recordIndex, MYRECORD_RECORD_t * record)
{
  /* This variable will be the index of the entry of the cache. */
  int cacheIndex = 0;

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* REMEMBER TO USE THE AUXILIARY FUNCTIONS ABOVE. */
  /* Search the cache to guess if there's already an entry for "fileIndex". */
  /* If the record was already in the cache use that entry. */
  cacheIndex = searchRecord (recordIndex);
  if (cacheIndex == -1)
    {
      /* If not, get an unused or clean entry. */
      cacheIndex = searchUnusedOrClean ();
      if (cacheIndex == -1)
        {
          /* If not, get a dirty entry, and flush it before reading on it. */
          cacheIndex = searchAny ();
          if (MYC_flushEntry (CacheEntries->buckets[cacheIndex].id * MYBUCKET_NRECORDS) == -1)
            {
              fprintf (stderr, "Error flushing entry to file.\n");
              return -1;
            }
        }
      /* Read from the file to the cache if needed. */
      if (readBucket (recordIndex / MYBUCKET_NRECORDS, cacheIndex) == -1)
        {
          fprintf (stderr, "Error reading entry to cache.\n");
          return -1;
        }
      /* Set the new entry to the current record. */
      CacheEntries->buckets[cacheIndex].id = recordIndex / MYBUCKET_NRECORDS;
      CacheEntries->dirty[cacheIndex] = 0;
      CacheEntries->used[cacheIndex] = -1;
    }

  /* Overwrite = copy from the record passed as argument to the record inside the bucket. */
  CacheEntries->dirty[cacheIndex] = -1;
  CacheEntries->used[cacheIndex] = -1;
  CacheEntries->buckets[cacheIndex].record[recordIndex % MYBUCKET_NRECORDS] = *record;
  CacheEntries->buckets[cacheIndex].exists[recordIndex % MYBUCKET_NRECORDS] = -1;

  /* Remember to update the bucket entry with the index of the file bucket that contains. */

  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/**
 * Forces the cache to write the contents of the bucket containing the record at
 * "recordIndex" in the file.
 * @param fileIndex This is the index of the entry of the file to be flushed.
 * @return -1 in case of I/O error. 0 is OK.
 */
int
MYC_flushEntry (int recordIndex)
{
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* Go through the cache and search the entry holding the record
   * number "fileIndex" of the file. */
  int cacheIndex = searchRecord (recordIndex);
  if (-1 == cacheIndex)
    {
      fprintf (stderr, "Error flushing entry to cache.\n");
      return -1;
    }
  /* If the entry is dirty, write it to disk. */
  if (CacheEntries->dirty[cacheIndex])
    {
      /* Always check errors*/
      if (writeBucket (cacheIndex, recordIndex / MYBUCKET_NRECORDS) == -1)
        {
          fprintf (stderr, "Error flushing entry to cache.\n");
          return -1;
        }
    }
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

/**
 * Flush any dirty entry in the cache inmediately.
 * @return 
 */
int
MYC_flushAll ()
{
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  /* Go through the cache and write all dirty entries to the file. */
  for (int cacheIndex = 0; cacheIndex < MYC_NUMENTRIES; cacheIndex++)
    {
      if (CacheEntries->used[cacheIndex] && CacheEntries->dirty[cacheIndex])
        {
          if (MYC_flushEntry (CacheEntries->buckets[cacheIndex].id * MYBUCKET_NRECORDS) == -1)
            {
              fprintf (stderr, "Error flushing entry to cache.\n");
              return -1;
            }
        }
    }
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  return 0;
}

