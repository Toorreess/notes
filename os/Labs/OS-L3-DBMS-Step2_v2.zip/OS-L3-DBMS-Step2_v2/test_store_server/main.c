/* 
 * File:   test_store_server
 * Author: Guillermo Pérez Trabado
 *
 * This file implements a primitive server implementing store server of the
 * DBMS.
 * 
 * This test uses the cache library to read and write records to disk.
 * It also uses the server side store API to read request and send back answers.
 */

#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <string.h>

#include <mycache.h>
#include <mystore_srv.h>

/* This macro controls the current debug level. Reduce it to 0 to speed-up
 * the program when it is working. */
#define DEBUG_LEVEL 2
/* This macro executes statement only if DEBUG_LEVEL is >= level
 * You want to use it to enable/disable printing of messages for debugging.
 * See examples of use in the program below. */
#define ondebuglevel(level,statement) if((DEBUG_LEVEL)>=(level)){statement;};

/* This is the main loop of the server */
int
main (int argc, char** argv)
{
  char *program = strdup (basename (argv[0]));
  fprintf (stderr, "%s:: server starting...\n", program);

  /* This function initializes the cache. */
  if (MYC_initCache () != 0)
    {
      fprintf (stderr, "Error initializing cache.\n");
      exit (1);
    }

  if (STORS_init () != 0)
    {
      fprintf (stderr, "Error initializing server side API.\n");
      /* Close cache as we end here. */
      MYC_closeCache ();
      exit (1);
    }

  while (1)
    {
      /* We need a request and an answer. */
      request_message_t req;
      answer_message_t answer;

      ondebuglevel (2, fprintf (stderr, "%s:: waiting for a request...\n", program););
      /* Wait for a request from a client. */
      int status = STORS_readrequest (&req);
      /* Check status and possible errors. */
      ondebuglevel (1, fprintf (stderr, "%s:: request received with op=%d\n", program, req.requested_op););

      /* Prepare an answer to our client. */
      /* Fill the answer type with the identity of the client sending the request. */

      /* Decode operation. */
      switch (req.requested_op)
        {
        case MYSCOP_READ:
          /* Implement read operation with cache library. */
          /* The index is provided in the request. */
          /* The record content must be stored in the answer. */
          answer.status = 0; /* Fill status with the result of the operation. */
          break;

        case MYSCOP_WRITE:
          /* Implement write operation with cache library. */
          /* The record to write and the index are provided in the request. */
          answer.status = 0; /* Fill status with the result of the operation. */
          break;

        default:
          /* Remark unknown operations to stderr!!!
           Maybe we are using a more advanced client who uses more
           operations than an older server. */
          answer.status = -1; /* You should have an special error for "Unknown operation" */
          break;
        }

      ondebuglevel (1, fprintf (stderr, "%s:: sending answer to %ld with status=%d\n", program, req.return_to, answer.status););
      /* Send back the answer */
      status = STORS_sendanswer (&answer);
      /* Check status and possible errors. */
      if (status != 0)
        {
          fprintf (stderr, "Problems sending back an answer.\n");
          /* Exit from main loop. */
          break;
        }
    }

  /* This server never ends (by now). But one day, it will be able to end. */

  /* Close the server side API. */
  if (STORS_close () != 0)
    {
      fprintf (stderr, "Error closing server API.\n");
      /* Do not exit without closing the cache!!! */
    }

  /* This function closes the cache. It flushes all the information inside the
   * cache that is not written to the file yet. */
  if (MYC_closeCache () != 0)
    {
      fprintf (stderr, "Error closing cache.\n");
      exit (1);
    }

  fprintf (stderr, "%s:: server ended OK.\n", program);
  return (EXIT_SUCCESS);
}

