/* 
 * File:   libmystore_cli.h
 * Author: Guillermo Pérez Trabado
 *
 * This file implements the library to communicate with the store server.
 * The communication uses System V IPC message queues.
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <string.h>
#include "mystore_cli.h"
#include "messages.h"

#define DEBUG_LEVEL 0

/************************************************************
 PRIVATE VARIABLES
 ************************************************************/

/* Use global variables to keep values between functions. */
/* Add the keyword "static" to hide them so that a global variable can't be seen outside
 * this module. */

/* This will be the descriptor for the message queue. */
static int message_queue = -1;

/************************************************************
 PRIVATE FUNCTIONS
 ************************************************************/


/* Write any private function you need in this part of the file. */

/* Use the keyword "static" before a function which is only used inside this file */


/************************************************************
 PUBLIC FUNCTIONS
 ************************************************************/

/* Functions without "static" will be visible from any other C file. */

/**
 * Initialize the client API: open message queue, etc.
 * @return -1 in case of error during initialization. 0 means OK.
 */
int
STORC_init ()
{

  /* Open message queue. Do not create it in the client if it does not exist yet.
   *  If the server is the only one creating the queue, the client could
   *  detect when the server is not running. */
  key_t key = (key_t) getuid ();
  message_queue = msgget (key, IPC_CREAT | IPC_EXCL | S_IRWXU);

  /* Don't forget to check status of system calls. */
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  if (message_queue == -1)
    {
      perror ("libmystore_cli STORC_init():: Failed to open message queue.");
      return -1;
    }
  /* Everything is OK */
  return 0;
}


/**
 * This function finishes the client API. You should not remove the queue in 
 * the client as thre may be more clients.
 * @return -1 in case of error during cleaning. 0 means OK.
 */
int
STORC_close ()
{

  /* Close the message queue. Do not remove it! */
  /* Set the message queue descriptor to -1 to indicate it is not open. */
  message_queue = -1;
  return 0;
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
}


/**
 * This function reads a record from the store server.
 * @param fileIndex This is the index of the record to read.
 * @param record This is a pointer to a record allocated by the user.
 * @return Return the status from the server. 0 is OK.
 */
int
STORC_read (int fileIndex, MYRECORD_RECORD_t *record)
{
  /* Send a request message to the server indicating the index to read. */
  int status;
  request_message_t request;
  
  /* Remember to create a unique number for each client and add it to the request.
   * The PID of the process is OK as identifier by now. */
  int cid = (int) getpid (); // Client ID
  
  /* Set-up the request message */
  request.index = fileIndex;
  request.mtype = cid;
  request.return_to = cid;
  request.requested_op = MYSCOP_READ;
  memcpy (&(request.data), &record, sizeof (MYRECORD_RECORD_t));

  status = msgsnd (message_queue, &request, sizeof (request), 0);

  /* Wait for an answer message from the server. This client should wait using its unique
   number to avoid that other clients steal the answer to this client. */
  request_message_t answer;
  status = msgrcv (message_queue, &answer, sizeof (request), cid, 0);

  /* Check return status and copy the record from the message if OK. */
  if(status == 0){
      memcpy (&record, &(answer.data), sizeof(MYRECORD_RECORD_t));
  }
  
  /* Copy return status from server. */
  return status;
}


/**
 * This function writes a record to the store server.
 * @param fileIndex This is the index of the record to write.
 * @param record This is a pointer to a record allocated by the user.
 * @return Return the status from the server. 0 is OK.
 */
int
STORC_write (int fileIndex, MYRECORD_RECORD_t *record)
{

  /* Send a request message to the server indicating the index to write and
   * include the record data to write. */
  int status;
  request_message_t request;

  /* Remember to create a unique number for each client and add it to the request.
   * The PID of the process is OK as identifier by now. */
  int cid = (int) getpid (); // Client ID

  /* Set-up the request message */
  request.mtype = cid;
  request.index = fileIndex;
  request.requested_op = MYSCOP_WRITE;
  request.return_to = cid;
  memcpy (&(request.data), &record, sizeof (MYRECORD_RECORD_t));

  status = msgsnd (message_queue, &request, sizeof (request), 0);
  if (status == -1)
    {
      perror ("libmystore_cli STORC_write() :: Error sending a request message.\n");
      return -1;
    }

  /* Wait for an answer message from the server. This client should wait using its unique
   number to avoid that other clients steal the answer to this client. */
  request_message_t answer;
  status = msgrcv (message_queue, &answer, sizeof (answer), cid, 0) == -1;
  
  /* Copy return status from server. */
  return status;
}
