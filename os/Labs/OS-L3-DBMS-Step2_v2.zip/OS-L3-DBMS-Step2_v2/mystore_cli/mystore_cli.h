/* 
 * File:   mystore_cli.h
 * Author: Guillermo Pérez Trabado
 *
 * This file defines the headers of a library to communicate with the store server.
 * 
 */

#ifndef MYSTORE_CLI_H
#define MYSTORE_CLI_H

#include <stdint.h>
#include <sys/types.h>

#include <myrecord.h>

#ifdef __cplusplus
extern "C"
{
#endif

  /* This function initializes the client API. */
  int STORC_init ();

  /* This function closes only the client API. Not the storage server. */
  int STORC_close ();

  /* This function reads a record from the storage server. */
  int STORC_read (int fileIndex, MYRECORD_RECORD_t *record);

  /* This function writes a record into the storage server. */
  int STORC_write (int fileIndex, MYRECORD_RECORD_t *record);

  /* This function flushes this record index inside the storage server. */
  int STORC_flush (int fileIndex);

  /* This function flushes all the entries in the storage server. */
  int STORC_flushAll ();

#ifdef __cplusplus
}
#endif

#endif /* MYSTORE_CLI_H */

