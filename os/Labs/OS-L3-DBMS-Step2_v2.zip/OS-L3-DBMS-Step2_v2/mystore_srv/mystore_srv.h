/* 
 * File:   mystore_srv.h
 * Author: Guillermo Pérez Trabado
 *
 * This file defines the headers of a library to implement communications at the
 * store server side. The library allows to receive request messages and to send
 * back answers.
 * 
 */

#ifndef MYSTORE_CLI_H
#define MYSTORE_CLI_H

#include <stdint.h>
#include <sys/types.h>

#include <myrecord.h>

#include <messages.h>

#ifdef __cplusplus
extern "C"
{
#endif

  /* This function initializes the server side of the API. */
  int STORS_init ();

  /* This function closes the server side of the API. */
  int STORS_close ();

  /* This function reads a request from the message queue. */
  int STORS_readrequest (request_message_t *request);

  /* This function sends back an answer to the message queue. */
  int STORS_sendanswer (answer_message_t *answer);

#ifdef __cplusplus
}
#endif

#endif /* MYSTORE_CLI_H */

