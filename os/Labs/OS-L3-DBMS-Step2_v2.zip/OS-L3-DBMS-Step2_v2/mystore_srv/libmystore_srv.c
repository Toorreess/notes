/* 
 * File:   libmystore_srv.h
 * Author: Guillermo Pérez Trabado
 *
 * This file implements the library to implement communications at the
 * store server side.
 * The communication uses System V IPC message queues.
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include "mystore_srv.h"
#include "messages.h"

#define DEBUG_LEVEL 0

/************************************************************
 PRIVATE VARIABLES
 ************************************************************/

/* Use global variables to keep values between functions. */
/* Add the keyword "static" to hide them so that a global variable can't be seen outside
 * this module. */

/* This will be the descriptor for the message queue. */
static int message_queue = -1;

/* This will be the queue */
static int queue;
/************************************************************
 PRIVATE FUNCTIONS
 ************************************************************/


/* Write any private function you need in this part of the file. */

/* Use the keyword "static" before a function which is only used inside this file */


/************************************************************
 PUBLIC FUNCTIONS
 ************************************************************/

/* Functions without "static" will be visible from any other C file. */

/**
 * Initialize the server library: open message queue, etc.
 * @return -1 in case of error during initialization. 0 means OK.
 */
int
STORS_init ()
{

  /* Open message queue. Create it in the server side exclusively.
   * It should failt if it already exists (see flag EXCL in man page).
   * The server should detect that another instance is running with
   * this method.
   */
  key_t key = (key_t) getuid ();
  queue = msgget (key, IPC_CREAT | IPC_EXCL);

  /* Don't forget to check status of system calls. */
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
  if (message_queue == -1)
    {
      perror ("libmystore_srv STORC_init() :: Failed to open message queue.");
      return -1;
    }
  /* Everything is OK */
  return 0;
}

/**
 * This function finishes the cache. It flushes all the information inside the
 * cache that is not written to the file yet and closes the file.
 * @return 
 */
int
STORS_close ()
{

  /* Close the message queue. Remove it! */
  if (message_queue != -1)
    {
      int status = msgctl (message_queue, IPC_RMID, NULL);
      if (status != 0)
        {
          perror ("libmystore_srv STORS_close() :: Error closing the message queue.\n");
          return -1;
        }
    }
  /* Set the message queue descriptor to -1 to indicate it is not open. */
  message_queue = -1;
  return 0;
  /* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ */
}

/**
 * This function reads a request from the message queue.
 * This function will wait blocked until it receives a request.
 * When returning, the request passed by reference as pameter will contain the
 * data of the request received from the message queue.
 * The request will be processes outside this library.
 * @param request Is a pointer to a request structure to return a request
 * received from the client.
 * @return Return 0 if OK. -1 in case of some error receiving.
 */
int
STORS_readrequest (request_message_t *request)
{
  int status;
  request_message_t response;

  /* Wait for a request received from a client through the message queue. */
  status = msgrcv (message_queue, &response, sizeof (response), 0, 0);
  if (status == -1)
    {
      perror ("libmystore_srv STORS_readrequest() :: Error receiving a request.\n");
      return -1;
    }

  if (memcpy (&request->data, &(response.data), sizeof (MYRECORD_RECORD_t)) == NULL)
    {
      perror ("libmystore_srv STORS_readrequest() :: Error copying the data received into request struct.\n");
      return -1;
    }

  /* If no error, return 0 and the request contains the received one. */
  return 0;
}

/* This function sends back an answer to the message queue. */

/**
 * This function send an answer structure to a client through a message queue.
 * @param answer This structure is already initialized and ready to be sent.
 * @return Return 0 if OK. -1 in case of some error sending.
 */
int
STORS_sendanswer (answer_message_t *answer)
{
  /* Send an answer message to some client. */
  int status;
  /* The answer already contains the type field with the identity of the client
   * which will receive the answer. This is came in the request structure.
   */
  status = msgsnd (message_queue, &answer, sizeof (answer), 0);

  /* Remember to create a unique number for each client and add it to the request in the client side.
   */
  if (status == -1)
    {
      perror ("libmystore_srv STORS_sendanswer() :: Error sending an answer.\n");
      return -1;
    }

  /* If no error, return 0 and the request contains the received one. */
  return 0;
}
