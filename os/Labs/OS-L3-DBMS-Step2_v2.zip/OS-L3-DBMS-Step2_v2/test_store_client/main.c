/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Guillermo Pérez Trabado
 *
 * Created on 06 de may de 2021, 15:01
 */

#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <string.h>

#include <mycache.h>
#include <mystore_cli.h>

/* This macro controls the current debug level. Reduce it to 0 to speed-up
 * the program when it is working. */
#define DEBUG_LEVEL 2
/* This macro executes statement only if DEBUG_LEVEL is >= level
 * You want to use it to enable/disable printing of messages for debugging.
 * See examples of use in the program below. */
#define ondebuglevel(level,statement) if((DEBUG_LEVEL)>=(level)){statement;};

/* Number of registers to use in the test. */
#define TEST_LENGTH 128
#define NUMBER_CACHE_ENTRIES 64

/*
 * This test uses the mystore client library to create some registers and then reads them again.
 * The requests need the store_engine server to be running to receive the requests.
 */
int
main (int argc, char** argv)
{
  char *program = strdup (basename (argv[0]));
  fprintf (stderr, "%s:: client starting...\n", program);

  /************************************************************/
  /* WRITE TEST */
  /************************************************************/

  /* This function initializes the client API. */
  if (STORC_init () != 0)
    {
      fprintf (stderr, "Error initializing client API.\n");
      exit (1);
    }

  /* This is a variable to hold one record. */
  MYRECORD_RECORD_t record;


  /* Fill register n times and create or update records. */
  for (int k = 1; k < 100; k++)
    for (int j = 1; j < TEST_LENGTH - NUMBER_CACHE_ENTRIES; j++)
      for (int i = j; i < j + NUMBER_CACHE_ENTRIES; i++)
        {
          /* Id of the record. */
          record.registerid = i;
          record.age = i;
          record.gender = -1;
          /* This is a fixed length string. Print into it directly. */
          snprintf (record.name, sizeof (record.name), "reg #%d", i);

          ondebuglevel (2, fprintf (stderr, "%s:: sending write request to server with record id=%d\n", program, record.registerid););
          /* Write record into storage. */
          int status = STORC_write (i, &record);
          ondebuglevel (2, fprintf (stderr, "%s:: received answer from server with status=%d\n", program, status););
          if (status != 0)
            {
              fprintf (stderr, "Error writing to the storage.\n");
              exit (1);
            }
        }

  /* This function ends the API. Not the server. */
  if (STORC_close () != 0)
    {
      fprintf (stderr, "Error closing API.\n");
      exit (1);
    }

  fprintf (stderr, "Write test ended OK.\n");

  /************************************************************/
  /* READ TEST */
  /************************************************************/

  /* Open API again. */
  if (STORC_init () != 0)
    {
      fprintf (stderr, "Error initializing client API.\n");
      exit (1);
    }

  /* Read register from storage. */
  for (int k = 1; k < 100; k++)
    for (int j = 1; j < TEST_LENGTH - NUMBER_CACHE_ENTRIES; j++)
      for (int i = j; i < j + NUMBER_CACHE_ENTRIES; i++)
        {
          ondebuglevel (2, fprintf (stderr, "%s:: sending read request to server with id=%d\n", program, i););
          /* Read from store server. */
          int status = STORC_read (i, &record);
          ondebuglevel (2, fprintf (stderr, "%s:: received answer from server with status=%d\n", program, status););
          if (status != 0)
            {
              fprintf (stderr, "Error reading from server.\n");
              exit (1);
            }

          /* Check that the index from the record matches the position. */
          if (record.registerid != i)
            {
              fprintf (stderr, "ERROR:: Register at %d contains id %d.\n", i, record.registerid);
            }
          else
            {
              /* Activa el nivel 3 para ver una salida extremadamente completa si tienes problemas con los valores leídos. */
              ondebuglevel (3, printf ("id: %u, age: %d, gender: %d, name: %s\n", record.registerid, record.age, record.gender, record.name););
            }
        }

  /* This function closes the API. */
  if (STORC_close () != 0)
    {
      fprintf (stderr, "Error closing client.\n");
      exit (1);
    }

  fprintf (stderr, "%s:: client ended OK.\n", program);
  return (EXIT_SUCCESS);
}

